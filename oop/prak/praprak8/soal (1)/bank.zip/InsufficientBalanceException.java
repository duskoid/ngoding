public class InsufficientBalanceException extends Exception {
    // Type your code
    public InsufficientBalanceException(String message){
        super(message);
    }
}
